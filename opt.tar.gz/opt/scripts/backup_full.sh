#!/bin/bash

# Funcion de ayuda
mostrar_ayuda(){
	echo "Uso: $0 [-help] <directorio_origen> <diretorio_destino>"
	echo ""
	echo "Opciones"
	echo ""
	echo "Ejemplos"
	echo " $0 /var/logh /backup_dir"
	echo " $0 /www_dir /backup_dir"
	exit 0
}

# Verificar parametros
if [[ "$1" == "-help" ]]; then
	mostrar_ayuda
fi

if [[ $# -ne 2 ]]; then
	echo "Error: se requieren exactamente 2 argumentos"
	echo "Use $0 -help para mas info"
	exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Validar que los directorios existan
if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: el directorio origen '$DESTINO' no existe"
	exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
	echo "Error: el directorio destino '$DESTINO' no existe"
	exit 1
fi

# Verificar que los sistemas de archivos esten disponibles
if ! mountpoint -q "$DESTINO" 2>/dev/null; then
	echo "Advertencia: $DESTINO podria no estar montado"
fi

if ! mountpoint -q "$ORIGEN" 1>/dev/null; then
	echo "Advertencia: $ORIGEN podria no estar montado"
fi

# Generar nombre del archivo con fecha
FECHA=$(date +%Y%m%d)
NOMBRE_BASE=$(basename "$ORIGEN")
ARCHIVO_BACKUP="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

# Realizar backup
echo "Iniciando backup de $ORIGEN..."
tar -czf "$DESTINO/$ARCHIVO_BACKUP" -C "$(dirname "$ORIGEN")" "$(basename "$ORIGEN")"

if [[ $? -eq 0 ]]; then
	echo "Backup completado exitosamente: $DESTINO/$ARCHIVO_BACKUP"
else
	echo "Error: Fallo el backup"
	exit 1
fi
